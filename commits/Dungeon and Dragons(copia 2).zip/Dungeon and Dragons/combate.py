# combate.py

import random
import os
from personajes import Heroe
from enemigos import Enemigo, dropear_objetos
from items import usar_item, crear_items_disponibles


def limpiar_pantalla():
    os.system('cls' if os.name == 'nt' else 'clear')


def combate(equipo, enemigos, inventario):
    limpiar_pantalla()
    print("¡Comienza el combate!")
    drops_oro = 0
    drops_almas = []

    while any(h.esta_vivo() for h in equipo) and any(e.esta_vivo() for e in enemigos):
        for heroe in [h for h in equipo if h.esta_vivo()]:
            if not any(e.esta_vivo() for e in enemigos):
                break
            limpiar_pantalla()
            print(f"Turno de {heroe.nombre}")
            print(
                f"Vida: {heroe.vida_actual}/{heroe.vida_max}, Ataque: {heroe.get_ataque()}, Defensa: {heroe.get_defensa()}")
            print("\nEnemigos vivos:")
            for i, enemigo in enumerate([e for e in enemigos if e.esta_vivo()], 1):
                print(f"{i}. {enemigo.nombre} (Vida: {enemigo.vida_actual}/{enemigo.vida_max})")
            print("\nOpciones: 1. Atacar, 2. Ataque Especial, 3. Usar Item, 4. Huir")
            try:
                accion = input("Elige una acción (1-4): ")
                if accion == "1":
                    limpiar_pantalla()
                    print("Enemigos vivos:")
                    for i, enemigo in enumerate([e for e in enemigos if e.esta_vivo()], 1):
                        print(f"{i}. {enemigo.nombre} (Vida: {enemigo.vida_actual}/{enemigo.vida_max})")
                    enemigo_idx = int(input(f"Elige enemigo (1-{len([e for e in enemigos if e.esta_vivo()])}): ")) - 1
                    enemigo = [e for e in enemigos if e.esta_vivo()][enemigo_idx]
                    heroe.atacar(enemigo)
                    print("Presiona Enter para continuar.")
                    input()
                elif accion == "2":
                    if heroe.turnos_para_especial >= 3:
                        limpiar_pantalla()
                        print("Enemigos vivos:")
                        for i, enemigo in enumerate([e for e in enemigos if e.esta_vivo()], 1):
                            print(f"{i}. {enemigo.nombre} (Vida: {enemigo.vida_actual}/{enemigo.vida_max})")
                        enemigo_idx = int(
                            input(f"Elige enemigo (1-{len([e for e in enemigos if e.esta_vivo()])}): ")) - 1
                        enemigo = [e for e in enemigos if e.esta_vivo()][enemigo_idx]
                        heroe.usar_ataque_especial(enemigo)
                        print("Presiona Enter para continuar.")
                        input()
                    else:
                        limpiar_pantalla()
                        print(f"No puedes usar el ataque especial. Turnos restantes: {3 - heroe.turnos_para_especial}")
                        print("Presiona Enter para continuar.")
                        input()
                        continue
                elif accion == "3":
                    if not inventario:
                        limpiar_pantalla()
                        print("No tienes ítems en el inventario.")
                        print("Presiona Enter para continuar.")
                        input()
                        continue
                    limpiar_pantalla()
                    print("Inventario:")
                    for i, item in enumerate(inventario, 1):
                        print(f"{i}. {item.nombre}")
                    item_idx = int(input(f"Elige ítem (1-{len(inventario)}): ")) - 1
                    usar_item(inventario[item_idx], heroe)
                    if inventario[item_idx].tipo in ["pocion_vida", "pocion_fuerza", "pocion_especial"]:
                        inventario.pop(item_idx)
                    print("Presiona Enter para continuar.")
                    input()
                elif accion == "4":
                    limpiar_pantalla()
                    if random.random() < 0.25:
                        print("¡Huyes exitosamente! Saltas a la siguiente mazmorra.")
                        print("Presiona Enter para continuar.")
                        input()
                        return True, 0, []
                    else:
                        print("¡Intento de huida fallido! Sufres un ataque sorpresa.")
                        for enemigo in [e for e in enemigos if e.esta_vivo()]:
                            heroe_vivo = random.choice([h for h in equipo if h.esta_vivo()])
                            enemigo.atacar(heroe_vivo)
                        print("Presiona Enter para continuar.")
                        input()
                        continue
                else:
                    limpiar_pantalla()
                    print("Opción inválida.")
                    print("Presiona Enter para continuar.")
                    input()
                    continue
            except (ValueError, IndexError):
                limpiar_pantalla()
                print("Entrada inválida. Pierdes el turno.")
                print("Presiona Enter para continuar.")
                input()
                continue

            if any(e.esta_vivo() for e in enemigos):
                limpiar_pantalla()
                enemigo = random.choice([e for e in enemigos if e.esta_vivo()])
                heroe_vivo = random.choice([h for h in equipo if h.esta_vivo()])
                enemigo.atacar(heroe_vivo)
                print("Presiona Enter para continuar.")
                input()

        for enemigo in enemigos:
            if not enemigo.esta_vivo() and enemigo.oro_drop > 0:
                oro, alma = dropear_objetos(enemigo)
                drops_oro += oro
                if alma:
                    drops_almas.append(alma)
                enemigo.oro_drop = 0

    limpiar_pantalla()
    if any(h.esta_vivo() for h in equipo):
        print("¡Victoria! Has derrotado a todos los enemigos.")
        if drops_oro or drops_almas:
            print(
                f"Obtienes {drops_oro} oro y {', '.join(almas for almas in drops_almas) if drops_almas else 'ninguna alma'}.")
        print("Presiona Enter para continuar.")
        input()
        return True, drops_oro, drops_almas
    else:
        print("¡Derrota! Tu equipo ha sido vencido.")
        print("Presiona Enter para continuar.")
        input()
        return False, drops_oro, drops_almas