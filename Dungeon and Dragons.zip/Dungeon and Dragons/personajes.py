# personajes.py
# Define las clases y la lógica para crear/seleccionar héroes.
# Cada héroe se representa como un diccionario con campos:
# nombre, clase, vida, vida_max, ataque, defensa, arma (None o dict), armadura (None o dict), inventario (lista)
# La función seleccionar_personajes() muestra las 5 clases disponibles,
# permite elegir 3 de ellas y asignarles un nombre personalizado.

import os

def limpiar_pantalla():
    os.system("cls" if os.name == "nt" else "clear")

# Plantilla de clases jugables y sus estadísticas base
CLASES = {
    "Guerrero": {"vida": 140, "ataque": 200, "defensa": 8},
    "Mago":     {"vida": 90,  "ataque": 30, "defensa": 3},
    "Arquero":  {"vida": 100, "ataque": 22, "defensa": 5},
    "Clerigo":  {"vida": 110, "ataque": 18, "defensa": 6},
    "Ladron":   {"vida": 95,  "ataque": 24, "defensa": 4}
}

def mostrar_clases():
    print("=== Clases disponibles ===")
    for i, (clase, s) in enumerate(CLASES.items(), start=1):
        print(f"{i}. {clase} - Vida: {s['vida']} | Ataque: {s['ataque']} | Defensa: {s['defensa']}")

def crear_heroe(clase_nombre, nombre_personal):
    base = CLASES[clase_nombre].copy()
    heroe = {
        "nombre": nombre_personal,
        "clase": clase_nombre,
        "vida": base["vida"],
        "vida_max": base["vida"],
        "ataque": base["ataque"],
        "defensa": base["defensa"],
        "arma": None,       # equipamiento (dict con clave 'atk_bonus')
        "armadura": None,   # equipamiento (dict con clave 'def_bonus')
        "inventario": []    # lista de items (p.ej. pociones)
    }
    return heroe

def seleccionar_personajes():
    """
    Interfaz por consola para seleccionar 3 héroes y nombrarlos.
    Devuelve una lista de 3 diccionarios (héroes).
    """
    limpiar_pantalla()
    print("=== Selecciona tu equipo de 3 héroes ===\n")
    equipo = []
    clases_disp = list(CLASES.keys())

    while len(equipo) < 3:
        mostrar_clases()
        eleccion = input(f"\nSelecciona la clase del héroe {len(equipo)+1} (número o nombre): ").strip()
        # acepta número o nombre
        try:
            idx = int(eleccion) - 1
            if idx < 0 or idx >= len(clases_disp):
                print("Opción inválida. Intentalo otra vez.")
                continue
            clase = clases_disp[idx]
        except Exception:
            # tratar como nombre
            if eleccion.capitalize() in clases_disp:
                clase = eleccion.capitalize()
            else:
                print("Clase no reconocida. Intenta con el nombre o el número.")
                continue

        if any(h["clase"] == clase for h in equipo):
            print("Ya seleccionaste un héroe de esa clase, elegí otra clase.")
            continue

        nombre_personal = input(f"Escribe un nombre para tu {clase} (o ENTER para nombre por defecto): ").strip()
        if nombre_personal == "":
            nombre_personal = clase

        heroe = crear_heroe(clase, nombre_personal)
        equipo.append(heroe)
        print(f"✅ Añadido: {heroe['nombre']} el {heroe['clase']}\n")

    input("Presiona ENTER para continuar...")
    limpiar_pantalla()
    return equipo
