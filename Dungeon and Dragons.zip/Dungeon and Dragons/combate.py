# combate.py
# Lógica del combate por turnos.
# - Recibe `equipo` (lista de héroes — diccionarios) y `enemigos` (lista de instancias Enemigo).
# - Modifica la vida de héroes y enemigos directamente (persistencia entre mazmorras).
# - Devuelve: oro ganado si victoria (int), -1 si derrota total.

# Reglas básicas:
# - Turno del jugador: elegís qué héroe actúa (vivo), luego su acción:
#     1) Atacar -> elegís enemigo objetivo -> daño = heroe.ataque + arma_bonus - 0
#     2) Usar poción -> si tiene poción en inventario se aplica
#     3) Huir -> 50% de éxito (si huís, terminas la run actual sin oro)
# - Turno de enemigos: cada enemigo vivo ataca a un héroe vivo al azar.
# - Daños mínimos = 1.

import os
import random
import time

def limpiar_pantalla():
    os.system("cls" if os.name == "nt" else "clear")

def combate(equipo, enemigos):
    limpiar_pantalla()
    print("⚔️  COMBATE INICIADO  ⚔️")
    input("Presiona ENTER para comenzar...")

    # estado de pociones temporales (ejemplo para pocion_fuerza)
    efectos_temporales = {}  # {heroe_nombre: {"atk_bonus": X, "turnos": Y}}

    while True:
        limpiar_pantalla()

        # Mostrar estado
        print("=== TU EQUIPO ===")
        for i, h in enumerate(equipo, start=1):
            status = f"{h['vida']}/{h['vida_max']} HP"
            arma = h['arma']['nombre'] if h['arma'] else "Ninguna"
            armadura = h['armadura']['nombre'] if h['armadura'] else "Ninguna"
            print(f"{i}. {h['nombre']} ({h['clase']}) - {status} | ATK {h['ataque']} | DEF {h['defensa']} | Arma: {arma} | Armadura: {armadura}")

        print("\n=== ENEMIGOS ===")
        for i, e in enumerate(enemigos, start=1):
            estado = f"{e.vida}/{e.vida_max} HP" if e.esta_vivo() else "💀 Muerto"
            print(f"{i}. {e.nombre} - {estado}")

        # Condiciones de fin de partida
        if all(not e.esta_vivo() for e in enemigos):
            oro_ganado = sum(e.oro for e in enemigos)
            print(f"\n🎉 ¡Victoria! Oro total de esta sala: {oro_ganado}")
            input("Presiona ENTER para continuar...")
            return oro_ganado

        if all(h["vida"] <= 0 for h in equipo):
            print("\n💀 Todos tus héroes han caído. Fin de la run.")
            input("Presiona ENTER para continuar...")
            return -1

        # --- Turno del jugador ---
        # Elegir héroe que actúa (por número)
        heroes_vivos = [ (i,h) for i,h in enumerate(equipo, start=1) if h["vida"] > 0 ]
        print("\nTu turno. Héroes disponibles para actuar:")
        for i,h in heroes_vivos:
            print(f"{i}. {h['nombre']} ({h['clase']}) - {h['vida']}/{h['vida_max']} HP")
        try:
            idx = int(input("Elige el número del héroe que actúa: ").strip())
            heroe = next(h for i,h in heroes_vivos if i == idx)
        except Exception:
            print("Selección inválida. Pierdes el turno.")
            heroe = None
            time.sleep(1)

        if heroe:
            print("\nAcciones:")
            print("1) Atacar")
            print("2) Usar poción")
            print("3) Huir (50% chance)")
            accion = input("Elige acción (1/2/3): ").strip()

            if accion == "1":
                # Elegir enemigo objetivo
                enemigos_vivos = [ (i,e) for i,e in enumerate(enemigos, start=1) if e.esta_vivo() ]
                if not enemigos_vivos:
                    print("No hay enemigos vivos.")
                else:
                    for i,e in enemigos_vivos:
                        print(f"{i}. {e.nombre} - {e.vida} HP")
                    try:
                        idx_e = int(input("Elige enemigo a atacar (número): ").strip())
                        objetivo = next(e for i,e in enemigos_vivos if i == idx_e)
                        # calcular daño: ataque del héroe + arma - nada (enemigos no tienen defensa propia)
                        arma_bonus = heroe['arma']['atk_bonus'] if heroe['arma'] else 0
                        daño = heroe['ataque'] + arma_bonus
                        # si hay efecto temporal (poción de fuerza)
                        if heroe['nombre'] in efectos_temporales:
                            daño += efectos_temporales[heroe['nombre']].get("atk_bonus", 0)
                        daño = max(1, daño)
                        objetivo.vida -= daño
                        print(f"\n{heroe['nombre']} ataca a {objetivo.nombre} e inflige {daño} de daño.")
                        if objetivo.vida <= 0:
                            print(f"¡{objetivo.nombre} ha sido derrotado!")
                    except Exception:
                        print("Objetivo inválido. Ataque fallido.")

            elif accion == "2":
                # usar pocion del inventario del héroe (si tiene)
                pocion_idx = None
                for i,it in enumerate(heroe['inventario'], start=1):
                    print(f"{i}. {it['nombre']}")
                if not heroe['inventario']:
                    print("No tienes pociones en este héroe.")
                else:
                    try:
                        sel = int(input("Elige pocion a usar (número): ").strip())
                        pocion = heroe['inventario'].pop(sel-1)
                        if pocion['tipo'] == 'pocion_vida':
                            heroe['vida'] = min(heroe['vida_max'], heroe['vida'] + pocion['curacion'])
                            print(f"{heroe['nombre']} recupera {pocion['curacion']} HP.")
                        elif pocion['tipo'] == 'pocion_fuerza':
                            # agregar efecto temporal
                            efectos_temporales[heroe['nombre']] = {"atk_bonus": pocion['bonus'], "turnos": pocion['duracion_turnos']}
                            print(f"{heroe['nombre']} gana +{pocion['bonus']} ATK por {pocion['duracion_turnos']} turnos.")
                        else:
                            print("Poción desconocida.")
                    except Exception:
                        print("Selección inválida de poción.")

            elif accion == "3":
                # huir: 50% chance
                chance = random.random()
                if chance < 0.5:
                    print("¡Huiste del combate! No recibes oro.")
                    input("Presiona ENTER para continuar...")
                    return 0  # huir no da oro, pero no es derrota completa
                else:
                    print("No pudiste huir. El combate continúa.")
            else:
                print("Acción inválida. Pierdes el turno.")

        time.sleep(1)

        # Reducir duración de efectos temporales
        for nombre in list(efectos_temporales.keys()):
            efectos_temporales[nombre]['turnos'] -= 1
            if efectos_temporales[nombre]['turnos'] <= 0:
                del efectos_temporales[nombre]

        # --- Turno de los enemigos ---
        limpiar_pantalla()
        print("Turno de los enemigos...\n")
        for e in enemigos:
            if not e.esta_vivo():
                continue
            # elegir héroe vivo al azar
            vivos = [h for h in equipo if h['vida'] > 0]
            if not vivos:
                break
            objetivo = random.choice(vivos)
            # calcular daño: ataque enemigo - (defensa + armadura)
            def_bonus = objetivo['armadura']['def_bonus'] if objetivo['armadura'] else 0
            daño = max(1, e.ataque - (objetivo['defensa'] + def_bonus))
            objetivo['vida'] -= daño
            print(f"{e.nombre} ataca a {objetivo['nombre']} e inflige {daño} de daño. ({objetivo['nombre']}: {max(0, objetivo['vida'])}/{objetivo['vida_max']} HP)")
            if objetivo['vida'] <= 0:
                print(f"¡{objetivo['nombre']} ha caído!")
            time.sleep(0.7)

        input("\nPresiona ENTER para el siguiente turno...")
