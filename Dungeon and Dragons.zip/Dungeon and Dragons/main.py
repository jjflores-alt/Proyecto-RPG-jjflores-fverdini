# main.py
# Punto de entrada del juego. Muestra la pantalla "Dungeon and Dragons",
# permite seleccionar personajes, recorre las 10 mazmorras, llama al combate,
# acumula oro y abre el campamento cada 3 mazmorras.

from personajes import seleccionar_personajes, limpiar_pantalla
from enemigos import obtener_enemigos_para_mazmorra
from combate import combate
from campamento import campamento

def pantalla_inicio():
    limpiar_pantalla()
    print("=======================================")
    print("        Dungeon and Dragons")
    print("=======================================")
    print("1) Jugar")
    print("2) Salir")
    ele = input("Elige una opción: ").strip()
    return ele

def main():
    ele = pantalla_inicio()
    if ele != "1":
        print("Saliendo... ¡Hasta la próxima!")
        return

    equipo = seleccionar_personajes()
    oro_total = 0

    # Bucle principal de mazmorras (1..10)
    for nivel in range(1, 11):
        limpiar_pantalla()
        print(f"🔸 Mazmorra {nivel} 🔸\n")
        enemigos = obtener_enemigos_para_mazmorra(nivel)
        # Mostrar resumen de enemigos
        if len(enemigos) == 1:
            e = enemigos[0]
            print(f"¡Aparece el boss {e.nombre} con {e.vida} HP!\n")
        else:
            print(f"¡Aparecen {len(enemigos)} enemigos!")
            for i,e in enumerate(enemigos, start=1):
                print(f"  {i}. {e.nombre} - {e.vida} HP - ATK {e.ataque}")
        input("\nPresiona ENTER para iniciar el combate...")

        resultado = combate(equipo, enemigos)
        if resultado == -1:
            print("\n💀 Tu equipo ha sido derrotado. Run terminada.")
            break
        else:
            # resultado puede ser 0 (huyó) o oro ganado (>0)
            oro_total += resultado
            print(f"\n💰 Oro acumulado: {oro_total}")

        # Punto de descanso cada 3 mazmorras (1-3, 4-6, 7-9) antes del siguiente bloque
        if nivel % 3 == 0 and nivel < 10:
            oro_total = campamento(equipo, oro_total)

        input("\nPresiona ENTER para seguir...")

    print("\n=== Fin de la aventura ===")
    print(f"Oro total conseguido: {oro_total}")
    print("Gracias por jugar. ¡Hasta la próxima!")

if __name__ == "__main__":
    main()
