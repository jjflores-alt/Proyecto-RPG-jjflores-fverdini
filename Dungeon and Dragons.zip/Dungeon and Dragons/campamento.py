# campamento.py
# Punto de descanso y tienda. Aca el jugador puede:
#  - Descansar (recuperar 50% de la vida máxima de cada héroe)
#  - Ir a la tienda para comprar pociones/armas/armaduras
#  - Pagar para curar completamente (si hay suficiente oro)

# Devuelve el oro actualizado y modifica el equipo en sitio.

import os
import time
from items import crear_pocion_vida, crear_pocion_fuerza, crear_arma_basica, crear_armadura_basica, aplicar_pocion_vida, equipar_arma, equipar_armadura

def limpiar_pantalla():
    os.system("cls" if os.name == "nt" else "clear")

def tienda(equipo, oro):
    while True:
        limpiar_pantalla()
        print("🏪 TIENDA DEL CAMPAMENTO")
        print(f"Tienes {oro} de oro.\n")
        print("1) Comprar Poción de Vida (100 HP) - 20 oro")
        print("2) Comprar Poción de Fuerza (+8 ATK x3 turnos) - 35 oro")
        print("3) Comprar Espada básica (+6 ATK) - 40 oro")
        print("4) Comprar Armadura ligera (+4 DEF) - 40 oro")
        print("5) Salir\n")
        ele = input("Elige opción: ").strip()
        if ele == "1":
            precio = 20
            if oro >= precio:
                oro -= precio
                p = crear_pocion_vida()
                # guardamos la poción en el primer héroe que la tenga disponible (o en inventario global)
                # Para simplicidad agregamos la poción al inventario del primer héroe vivo (cambiar para elegir a que heroe ponerle el item)
                for h in equipo:
                    if h["vida"] > 0:
                        h["inventario"].append(p)
                        break
                print("Compraste una Poción de Vida y se guardó en el inventario de un héroe.")
            else:
                print("No tienes oro suficiente.")
        elif ele == "2":
            precio = 35
            if oro >= precio:
                oro -= precio
                p = crear_pocion_fuerza()
                for h in equipo:
                    if h["vida"] > 0:
                        h["inventario"].append(p)
                        break
                print("Compraste una Poción de Fuerza.")
            else:
                print("No tienes oro suficiente.")
        elif ele == "3":
            precio = 40
            if oro >= precio:
                oro -= precio
                arma = crear_arma_basica()
                # dejamos la decisión de equipar al jugador ahora: equipamos al primer héroe vivo por defecto (cambiar)
                for h in equipo:
                    if h["vida"] > 0:
                        equipar_arma(h, arma)
                        break
                print("Compraste y equipaste una Espada básica a un héroe vivo.")
            else:
                print("No tienes oro suficiente.")
        elif ele == "4":
            precio = 40
            if oro >= precio:
                oro -= precio
                arm = crear_armadura_basica()
                for h in equipo:
                    if h["vida"] > 0:
                        equipar_armadura(h, arm)
                        break
                print("Compraste y equipaste una Armadura ligera a un héroe vivo.")
            else:
                print("No tienes oro suficiente.")
        elif ele == "5":
            return oro
        else:
            print("Opción inválida.")
        input("Presiona ENTER para continuar...")

def descansar(equipo):
    limpiar_pantalla()
    print("🏕️ Descansando... tus héroes recuperan el 50% de su vida máxima.")
    for h in equipo:
        if h['vida'] > 0:
            resta = int(h['vida_max'] * 0.5)
            h['vida'] = min(h['vida_max'], h['vida'] + resta)
    time.sleep(1.5)
    input("Presiona ENTER para continuar...")

def campamento(equipo, oro):
    """
    Punto de descanso que se llama entre mazmorras.
    Devuelve el oro actualizado (y modifica equipo in-place: items, vida, etc.).
    """
    while True:
        limpiar_pantalla()
        print("🏕️ Has llegado al campamento.")
        print(f"Tienes {oro} de oro.\n")
        print("Opciones:")
        print("1) Descansar (recupera 50% HP a cada héroe)")
        print("2) Ir a la tienda")
        print("3) Curar completamente a todo el equipo (costo: 50 oro)")
        print("4) Continuar aventura\n")
        ele = input("Elige una opción: ").strip()
        if ele == "1":
            descansar(equipo)
        elif ele == "2":
            oro = tienda(equipo, oro)
        elif ele == "3":
            if oro >= 50:
                oro -= 50
                for h in equipo:
                    h['vida'] = h['vida_max']
                print("Todos los héroes han sido curados completamente.")
                input("Presiona ENTER para continuar...")
            else:
                print("No tienes suficiente oro.")
                input("Presiona ENTER para continuar...")
        elif ele == "4":
            return oro
        else:
            print("Opción inválida.")
            input("Presiona ENTER para continuar...")
