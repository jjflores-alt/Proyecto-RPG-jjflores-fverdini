# items.py
# ----------------
# Define elementos que se compran/usan: pociones, armas y armaduras.
# También contiene funciones de ayuda para comprar y aplicar efectos.

def crear_pocion_vida():
    # Devuelve un dict representando la poción
    return {"tipo": "pocion_vida", "curacion": 100, "precio": 20, "nombre": "Poción de Vida (100 HP)"}

def crear_pocion_fuerza():
    return {"tipo": "pocion_fuerza", "bonus": 8, "duracion_turnos": 3, "precio": 35, "nombre": "Poción de Fuerza (+8 ATK x3)"}

def crear_arma_basica():
    return {"tipo": "arma", "atk_bonus": 6, "precio": 40, "nombre": "Espada básica (+6 ATK)"}

def crear_armadura_basica():
    return {"tipo": "armadura", "def_bonus": 4, "precio": 40, "nombre": "Armadura ligera (+4 DEF)"}


# Función para listar tienda
def tienda_mostrar():
    print("=== Tienda ===")
    print("1) Poción de Vida (100 HP) - 20 oro")
    print("2) Poción de Fuerza (+8 ATK por 3 turnos) - 35 oro")
    print("3) Espada básica (+6 ATK) - 40 oro")
    print("4) Armadura ligera (+4 DEF) - 40 oro")
    print("5) Salir")

# Aplicar objeto al héroe (usada cuando se consume o equipa)
def aplicar_pocion_vida(heroe, pocion):
    heroe["vida"] = min(heroe["vida_max"], heroe["vida"] + pocion["curacion"])

def equipar_arma(heroe, arma):
    heroe["arma"] = arma
    # no cambiamos ataque base para permitir remoción más tarde; en combate sumamos arma['atk_bonus']

def equipar_armadura(heroe, armadura):
    heroe["armadura"] = armadura
