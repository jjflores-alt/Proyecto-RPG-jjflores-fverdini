# enemigos.py
# Define la clase Enemigo y las funciones para crear enemigos según la mazmorra.
# Cada enemigo es una instancia de Enemigo con atributos independientes,
# por eso al pedir "3 duendes" generamos 3 instancias nuevas (no compartidas).

import random

class Enemigo:
    def __init__(self, nombre, vida, ataque, oro):
        self.nombre = nombre
        self.vida = vida
        self.vida_max = vida
        self.ataque = ataque
        self.oro = oro

    def esta_vivo(self):
        return self.vida > 0

# Plantillas por tipo con valores base
STATS = {
    "duende": {"nombre": "Duende", "vida": 40,  "ataque": 8,  "oro": 8},
    "lobo":   {"nombre": "Lobo",   "vida": 60,  "ataque": 12, "oro": 15},
    "orco":   {"nombre": "Orco",   "vida": 100, "ataque": 18, "oro": 30},
    "dragon": {"nombre": "Dragón", "vida": 300, "ataque": 36, "oro": 200}
}

def crear_enemigo(tipo):
    s = STATS[tipo]
    # añadir pequeña variación para variedad
    vida = s["vida"] + random.randint(-5, 10)
    ataque = s["ataque"] + random.randint(-2, 3)
    oro = s["oro"] + random.randint(0, int(s["oro"]*0.2))
    return Enemigo(s["nombre"], vida, ataque, oro)

def obtener_enemigos_para_mazmorra(nivel, cantidad=3):
    """
    Devuelve una lista de instancias Enemigo según el número de mazmorra.
    - niveles 1-3: duendes
    - niveles 4-6: lobos
    - niveles 7-9: orcos
    - nivel 10: 1 dragón (boss)
    """
    if 1 <= nivel <= 3:
        tipo = "duende"
    elif 4 <= nivel <= 6:
        tipo = "lobo"
    elif 7 <= nivel <= 9:
        tipo = "orco"
    elif nivel == 10:
        # solo 1 dragón en la mazmorra final
        return [crear_enemigo("dragon")]
    else:
        tipo = "duende"

    return [crear_enemigo(tipo) for _ in range(cantidad)]
